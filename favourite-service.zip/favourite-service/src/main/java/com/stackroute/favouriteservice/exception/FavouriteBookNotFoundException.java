package com.stackroute.favouriteservice.exception;

@SuppressWarnings("serial")
public class FavouriteBookNotFoundException extends Exception {

	public FavouriteBookNotFoundException(String message) {
		super(message);
	}

	

}